import { useState, useEffect, useRef } from "react";
import Sidebar, { type Page } from "./components/layout/Sidebar";
import Header from "./components/layout/Header";
import Overview from "./pages/Overview";
import Network from "./pages/Network";
import Predictions from "./pages/Predictions";
import Events from "./pages/Events";
import Controls from "./pages/Controls";
import {
  mockSystemStatus,
  mockTelemetry,
  mockForecast,
  mockPrediction,
  mockTopology,
  mockEvents,
  mockAttackEvents,
  mockLogLines,
  mockSiteInfo,
} from "./api/mockData";
import type {
  SystemStatus,
  TelemetryPoint,
  ForecastPoint,
  PredictionResult,
  Topology,
  NetworkEvent,
  AttackEvent,
  SiteInfo,
} from "./api/types";

const PAGE_TITLES: Record<Page, string> = {
  overview: "Overview",
  network: "Network Topology",
  predictions: "Predictions & Forecasting",
  events: "Events & Logs",
  controls: "System Controls",
};

export default function App() {
  const [page, setPage] = useState<Page>("overview");
  const [status, setStatus] = useState<SystemStatus | null>(mockSystemStatus);
  const [telemetry, setTelemetry] = useState<TelemetryPoint[]>(mockTelemetry);
  const [forecast] = useState<ForecastPoint[]>(mockForecast);
  const [prediction] = useState<PredictionResult | null>(mockPrediction);
  const [topology, setTopology] = useState<Topology | null>(mockTopology);
  const [events, setEvents] = useState<NetworkEvent[]>(mockEvents);
  const [attackEvents] = useState<AttackEvent[]>(mockAttackEvents);
  const [logLines, setLogLines] = useState<string[]>(mockLogLines);
  const [site] = useState<SiteInfo | null>(mockSiteInfo);
  const [wsConnected] = useState(false); // mock: no real WS
  const [darkMode, setDarkMode] = useState(false);

  const toggleDark = () => {
    setDarkMode((d) => {
      document.documentElement.classList.toggle("dark", !d);
      return !d;
    });
  };

  // Simulate live telemetry ticks
  const tickRef = useRef(0);
  useEffect(() => {
    const id = setInterval(() => {
      tickRef.current += 1;
      const t = tickRef.current;

      setStatus((prev) => {
        if (!prev) return prev;
        const noise = (Math.random() - 0.5) * 40;
        return {
          ...prev,
          throughput: Math.max(100, Math.min(1000, prev.throughput + noise)),
          latency: Math.max(5, Math.min(80, prev.latency + (Math.random() - 0.5) * 4)),
          anomalyScore: Math.max(0, Math.min(100, prev.anomalyScore + (Math.random() - 0.45) * 3)),
          activeConnections: Math.max(0, prev.activeConnections + Math.round((Math.random() - 0.5) * 40)),
          lastUpdate: new Date().toISOString(),
        };
      });

      setTelemetry((prev) => {
        const last = prev[prev.length - 1];
        const observed = Math.max(0, last.observed + (Math.random() - 0.5) * 80);
        const predicted = Math.max(0, last.predicted + (Math.random() - 0.5) * 20);
        const band = 45;
        const newPoint = {
          timestamp: new Date().toISOString(),
          observed: Math.round(observed),
          predicted: Math.round(predicted),
          upperBound: Math.round(predicted + band),
          lowerBound: Math.max(0, Math.round(predicted - band)),
          confidence: 0.88 + (Math.random() - 0.5) * 0.1,
          anomalyScore: Math.random() * 30 + 60,
        };
        return [...prev.slice(-89), newPoint];
      });

      // Simulate occasional new log line
      if (t % 8 === 0) {
        const samples = [
          `[${new Date().toISOString()}] ml[stream] INFO: telemetry batch processed ${Math.round(900 + Math.random() * 200)} flows`,
          `[${new Date().toISOString()}] rt01 INFO: ECMP path recalculated — latency ${Math.round(10 + Math.random() * 30)}ms`,
          `[${new Date().toISOString()}] fw INFO: connection table ${Math.round(3000 + Math.random() * 1000)} entries`,
          `[${new Date().toISOString()}] ids INFO: heartbeat OK — ruleset v2026.09.11-1 active`,
        ];
        setLogLines((prev) => [...prev, samples[t % samples.length]].slice(-100));
      }
    }, 2000);

    return () => clearInterval(id);
  }, []);

  return (
    <div style={{ display: "flex", height: "100%", overflow: "hidden", background: "var(--color-base)" }}>
      <Sidebar activePage={page} onNavigate={setPage} status={status} />

      <div style={{ flex: 1, display: "flex", flexDirection: "column", overflow: "hidden" }}>
        <Header
          status={status}
          site={site}
          wsConnected={wsConnected}
          pageTitle={PAGE_TITLES[page]}
          darkMode={darkMode}
          onToggleDark={toggleDark}
        />

        <main style={{ flex: 1, overflow: "hidden" }}>
          {page === "overview" && (
            <Overview
              status={status}
              telemetry={telemetry}
              forecast={forecast}
              prediction={prediction}
              attackEvents={attackEvents}
              events={events}
              topology={topology}
              logLines={logLines}
            />
          )}
          {page === "network" && <Network topology={topology} />}
          {page === "predictions" && (
            <Predictions telemetry={telemetry} forecast={forecast} prediction={prediction} />
          )}
          {page === "events" && <Events events={events} logLines={logLines} />}
          {page === "controls" && (
            <Controls
              status={status}
              logLines={logLines}
              onCommandSent={(_cmd, line) => setLogLines((prev) => [...prev, line].slice(-100))}
            />
          )}
        </main>
      </div>
    </div>
  );
}
