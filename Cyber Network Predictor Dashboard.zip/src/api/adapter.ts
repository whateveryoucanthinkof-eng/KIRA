/**
 * API / WebSocket adapter layer.
 * Swap the BASE_URL and WS_URL constants and remove the mock fallbacks
 * to connect to a real backend. All UI components receive data through
 * props/state — none of them import from this file directly.
 */

import type {
  SystemStatus,
  Topology,
  SiteInfo,
  MitigationPayload,
  WSHandlers,
  WSEvent,
} from "./types";

export const BASE_URL = "/api";
export const WS_URL = `${location.protocol === "https:" ? "wss" : "ws"}://${location.host}/ws`;

// ─── REST helpers ────────────────────────────────────────────────────────────

async function apiFetch<T>(path: string, options?: RequestInit): Promise<T> {
  const res = await fetch(`${BASE_URL}${path}`, {
    headers: { "Content-Type": "application/json" },
    ...options,
  });
  if (!res.ok) throw new Error(`API ${path} → ${res.status} ${res.statusText}`);
  return res.json() as Promise<T>;
}

export async function fetchStatus(): Promise<SystemStatus> {
  return apiFetch<SystemStatus>("/status");
}

export async function fetchSite(): Promise<SiteInfo> {
  return apiFetch<SiteInfo>("/site");
}

export async function fetchTopology(): Promise<Topology> {
  return apiFetch<Topology>("/topology");
}

export async function sendCommand(command: string): Promise<void> {
  await apiFetch<void>(`/command/${command}`, { method: "POST" });
}

export async function sendMitigate(payload: MitigationPayload): Promise<void> {
  await apiFetch<void>("/mitigate", {
    method: "POST",
    body: JSON.stringify(payload),
  });
}

// ─── WebSocket ────────────────────────────────────────────────────────────────

export function connectWebSocket(handlers: WSHandlers): WebSocket {
  const ws = new WebSocket(WS_URL);

  ws.onopen = () => handlers.onOpen?.();
  ws.onerror = (e) => handlers.onError?.(e);
  ws.onclose = () => handlers.onClose?.();

  ws.onmessage = (event) => {
    let parsed: WSEvent;
    try {
      parsed = JSON.parse(event.data as string) as WSEvent;
    } catch {
      return;
    }
    const p = parsed.payload;
    switch (parsed.type) {
      case "prediction":
        handlers.onPrediction?.(p as Parameters<NonNullable<WSHandlers["onPrediction"]>>[0]);
        break;
      case "topology_update":
        handlers.onTopologyUpdate?.(p as Topology);
        break;
      case "ml_reset":
        handlers.onMLReset?.(p as { reason: string });
        break;
      case "system_status":
        handlers.onSystemStatus?.(p as SystemStatus);
        break;
      case "command_started":
        handlers.onCommandStarted?.(p as { command: string });
        break;
      case "command_completed":
        handlers.onCommandCompleted?.(
          p as Parameters<NonNullable<WSHandlers["onCommandCompleted"]>>[0]
        );
        break;
      case "command_output":
        handlers.onCommandOutput?.(p as { command: string; line: string });
        break;
      case "attack_event":
        handlers.onAttackEvent?.(
          p as Parameters<NonNullable<WSHandlers["onAttackEvent"]>>[0]
        );
        break;
    }
  };

  return ws;
}
