import type {
  SystemStatus,
  TelemetryPoint,
  Topology,
  NetworkEvent,
  AttackEvent,
  SiteInfo,
  ForecastPoint,
  ContributingSignal,
  PredictionResult,
} from "./types";

function iso(offsetMinutes = 0): string {
  return new Date(Date.now() - offsetMinutes * 60000).toISOString();
}

function isoSec(offsetSeconds = 0): string {
  return new Date(Date.now() - offsetSeconds * 1000).toISOString();
}

export const mockSiteInfo: SiteInfo = {
  name: "PROD-DC-EAST-01",
  location: "Ashburn, VA — us-east-1",
  timezone: "America/New_York",
  subnet: "10.12.0.0/20",
  externalIp: "203.0.113.42",
  description: "Primary production data center, east coast edge",
};

export const mockSystemStatus: SystemStatus = {
  networkStatus: "running",
  telemetryStatus: "running",
  predictionStatus: "running",
  attackStatus: "active",
  uptime: 345678,
  lastUpdate: iso(0),
  anomalyScore: 72,
  threatLevel: "high",
  packetLoss: 0.3,
  latency: 14,
  throughput: 842,
  activeConnections: 3847,
};

// 90 points, last 90 minutes
function generateTelemetry(): TelemetryPoint[] {
  const base = 600;
  const points: TelemetryPoint[] = [];
  for (let i = 89; i >= 0; i--) {
    const noise = (Math.random() - 0.5) * 80;
    const spike = i < 20 ? 180 + Math.random() * 120 : 0; // attack spike
    const observed = Math.max(0, base + noise + spike + Math.sin(i / 10) * 60);
    const predicted = Math.max(0, base + Math.sin(i / 10) * 60 + (i < 20 ? 140 : 0));
    const band = 40 + (i < 20 ? 80 : 0);
    points.push({
      timestamp: iso(i),
      observed: Math.round(observed),
      predicted: Math.round(predicted),
      upperBound: Math.round(predicted + band),
      lowerBound: Math.max(0, Math.round(predicted - band)),
      confidence: i < 20 ? 0.61 : 0.91,
      anomalyScore: i < 25 && i >= 5 ? 60 + Math.random() * 35 : Math.random() * 20,
    });
  }
  return points;
}

export const mockTelemetry: TelemetryPoint[] = generateTelemetry();

function generateForecast(): ForecastPoint[] {
  const last = mockTelemetry[mockTelemetry.length - 1];
  const base = last.predicted;
  const points: ForecastPoint[] = [];
  for (let i = 1; i <= 30; i++) {
    const predicted = Math.max(0, base + Math.sin(i / 8) * 50 - i * 2);
    const band = 50 + i * 3;
    points.push({
      timestamp: new Date(Date.now() + i * 60000).toISOString(),
      predicted: Math.round(predicted),
      upperBound: Math.round(predicted + band),
      lowerBound: Math.max(0, Math.round(predicted - band)),
      confidence: Math.max(0.4, 0.91 - i * 0.018),
    });
  }
  return points;
}

export const mockForecast: ForecastPoint[] = generateForecast();

export const mockContributingSignals: ContributingSignal[] = [
  { name: "Packet rate (5m avg)", weight: 0.34, direction: "positive", value: "12,847 pps" },
  { name: "Connection entropy", weight: 0.21, direction: "positive", value: "3.82 bits" },
  { name: "SYN/ACK ratio", weight: 0.18, direction: "positive", value: "0.71" },
  { name: "Source IP diversity", weight: 0.12, direction: "positive", value: "1,203 unique" },
  { name: "Protocol distribution", weight: 0.08, direction: "neutral", value: "TCP 84%" },
  { name: "Time-of-day baseline", weight: 0.05, direction: "negative", value: "−14%" },
  { name: "Known threat feeds", weight: 0.02, direction: "positive", value: "7 matches" },
];

export const mockPrediction: PredictionResult = {
  timestamp: iso(0),
  value: 0.84,
  confidence: 0.73,
  horizon: 15,
  model: "LSTM-v4.2 / gradient-boosted ensemble",
  signals: mockContributingSignals,
};

export const mockTopology: Topology = {
  lastUpdated: iso(0),
  nodes: [
    {
      id: "internet",
      label: "Internet",
      type: "internet",
      status: "online",
      x: 400,
      y: 40,
    },
    {
      id: "attacker",
      label: "Attacker",
      type: "attacker",
      ip: "198.51.100.247",
      status: "compromised",
      x: 660,
      y: 40,
    },
    {
      id: "fw01",
      label: "FW-EDGE-01",
      type: "firewall",
      ip: "203.0.113.1",
      status: "warning",
      x: 400,
      y: 130,
      services: ["pf 2.7", "IDS/IPS"],
    },
    {
      id: "rt01",
      label: "CORE-RT-01",
      type: "router",
      ip: "10.12.0.1",
      status: "online",
      x: 400,
      y: 230,
      services: ["BGP", "OSPF"],
    },
    {
      id: "sw-dmz",
      label: "SW-DMZ-01",
      type: "switch",
      ip: "10.12.1.1",
      status: "online",
      x: 210,
      y: 330,
    },
    {
      id: "sw-int",
      label: "SW-INT-01",
      type: "switch",
      ip: "10.12.2.1",
      status: "online",
      x: 590,
      y: 330,
    },
    {
      id: "web01",
      label: "WEB-01",
      type: "server",
      ip: "10.12.1.10",
      status: "compromised",
      x: 80,
      y: 440,
      services: ["nginx 1.26", "TLS 1.3"],
      os: "Ubuntu 24.04",
    },
    {
      id: "mail01",
      label: "MAIL-01",
      type: "server",
      ip: "10.12.1.11",
      status: "online",
      x: 210,
      y: 440,
      services: ["Postfix", "Dovecot"],
      os: "Debian 12",
    },
    {
      id: "dns01",
      label: "DNS-01",
      type: "server",
      ip: "10.12.1.12",
      status: "degraded",
      x: 340,
      y: 440,
      services: ["BIND 9.18"],
      os: "Ubuntu 22.04",
    },
    {
      id: "db01",
      label: "DB-PRIM-01",
      type: "server",
      ip: "10.12.2.20",
      status: "online",
      x: 480,
      y: 440,
      services: ["PostgreSQL 16", "PgBouncer"],
      os: "RHEL 9",
    },
    {
      id: "app01",
      label: "APP-01",
      type: "server",
      ip: "10.12.2.21",
      status: "online",
      x: 600,
      y: 440,
      services: ["Java 21", "Tomcat 10"],
      os: "Ubuntu 24.04",
    },
    {
      id: "admin01",
      label: "ADMIN-WS",
      type: "host",
      ip: "10.12.2.100",
      status: "online",
      x: 720,
      y: 440,
      os: "macOS 15.1",
    },
  ],
  edges: [
    { id: "e1", source: "internet", target: "fw01", status: "suspicious", utilization: 91, bandwidth: 1000 },
    { id: "e2", source: "attacker", target: "fw01", status: "suspicious", utilization: 85, bandwidth: 100 },
    { id: "e3", source: "fw01", target: "rt01", status: "active", utilization: 74, bandwidth: 10000 },
    { id: "e4", source: "rt01", target: "sw-dmz", status: "active", utilization: 68, bandwidth: 10000 },
    { id: "e5", source: "rt01", target: "sw-int", status: "active", utilization: 42, bandwidth: 10000 },
    { id: "e6", source: "sw-dmz", target: "web01", status: "saturated", utilization: 95, bandwidth: 1000 },
    { id: "e7", source: "sw-dmz", target: "mail01", status: "active", utilization: 22, bandwidth: 1000 },
    { id: "e8", source: "sw-dmz", target: "dns01", status: "active", utilization: 31, bandwidth: 1000 },
    { id: "e9", source: "sw-int", target: "db01", status: "active", utilization: 38, bandwidth: 10000 },
    { id: "e10", source: "sw-int", target: "app01", status: "active", utilization: 55, bandwidth: 1000 },
    { id: "e11", source: "sw-int", target: "admin01", status: "active", utilization: 8, bandwidth: 1000 },
    { id: "e12", source: "web01", target: "app01", status: "suspicious", utilization: 72, bandwidth: 1000 },
  ],
};

export const mockEvents: NetworkEvent[] = [
  {
    id: "ev-001",
    timestamp: isoSec(12),
    severity: "critical",
    category: "intrusion",
    source: "198.51.100.247",
    destination: "10.12.1.10",
    message: "SQL injection attempt detected — 47 payload variants in 8s",
    protocol: "HTTP",
    port: 80,
    raw: '[2026-09-11T14:32:41Z] ids[1234] ALERT: ET SQL Injection -- BLIND (3)',
  },
  {
    id: "ev-002",
    timestamp: isoSec(34),
    severity: "critical",
    category: "intrusion",
    source: "198.51.100.247",
    destination: "10.12.1.10",
    message: "Brute-force login on /wp-admin — 312 attempts in 2m",
    protocol: "HTTPS",
    port: 443,
    raw: '[2026-09-11T14:32:19Z] auth WARN: brute-force from 198.51.100.247',
  },
  {
    id: "ev-003",
    timestamp: isoSec(78),
    severity: "error",
    category: "anomaly",
    source: "10.12.1.10",
    destination: "10.12.2.21",
    message: "Lateral movement: WEB-01 → APP-01 unexplained POST /internal/exec",
    protocol: "HTTP",
    port: 8080,
    raw: '[2026-09-11T14:31:35Z] fw DENY lateral POST 10.12.1.10->10.12.2.21:8080',
  },
  {
    id: "ev-004",
    timestamp: isoSec(142),
    severity: "warning",
    category: "traffic",
    source: "10.12.1.12",
    message: "DNS-01 query rate 4.2× above baseline (possible DNS tunneling)",
    protocol: "DNS",
    port: 53,
    raw: '[2026-09-11T14:30:31Z] dns WARN: query_rate=18420/min baseline=4400/min',
  },
  {
    id: "ev-005",
    timestamp: isoSec(203),
    severity: "warning",
    category: "auth",
    source: "10.12.2.100",
    destination: "10.12.2.20",
    message: "Privileged DB role escalation from admin workstation — unexpected time",
    protocol: "TCP",
    port: 5432,
    raw: '[2026-09-11T14:29:30Z] pgsql WARN: role escalation admin->superuser',
  },
  {
    id: "ev-006",
    timestamp: isoSec(310),
    severity: "error",
    category: "firewall",
    source: "198.51.100.247",
    message: "Firewall rule bypass attempt — fragmented packet sequence",
    protocol: "TCP",
    raw: '[2026-09-11T14:27:43Z] fw ALERT: fragmented bypass sequence from 198.51.100.247',
  },
  {
    id: "ev-007",
    timestamp: isoSec(450),
    severity: "info",
    category: "system",
    source: "FW-EDGE-01",
    message: "IDS signature database updated — 47,382 rules loaded",
    raw: '[2026-09-11T14:25:23Z] ids INFO: ruleset updated v2026.09.11-1',
  },
  {
    id: "ev-008",
    timestamp: isoSec(612),
    severity: "warning",
    category: "traffic",
    source: "10.12.1.10",
    message: "WEB-01 outbound traffic 12× baseline — possible data exfiltration",
    protocol: "HTTPS",
    port: 443,
    raw: '[2026-09-11T14:22:41Z] fw WARN: outbound spike web01 12x baseline',
  },
  {
    id: "ev-009",
    timestamp: isoSec(780),
    severity: "info",
    category: "prediction",
    source: "ML-ENGINE",
    message: "Prediction model updated — LSTM-v4.2 retrained on 72h window",
    raw: '[2026-09-11T14:19:53Z] ml INFO: model retrained accuracy=0.924',
  },
  {
    id: "ev-010",
    timestamp: isoSec(920),
    severity: "info",
    category: "system",
    source: "CORE-RT-01",
    message: "OSPF adjacency re-established with SW-INT-01",
    raw: '[2026-09-11T14:17:33Z] ospf INFO: adjacency up 10.12.2.1',
  },
];

export const mockAttackEvents: AttackEvent[] = [
  {
    id: "atk-001",
    timestamp: isoSec(15),
    type: "SQL Injection",
    sourceIp: "198.51.100.247",
    targetIp: "10.12.1.10",
    severity: "critical",
    stage: "Exploitation",
    bytes: 48210,
    packets: 312,
    mitigated: false,
  },
  {
    id: "atk-002",
    timestamp: isoSec(78),
    type: "Lateral Movement",
    sourceIp: "10.12.1.10",
    targetIp: "10.12.2.21",
    severity: "error",
    stage: "Pivot",
    bytes: 12480,
    packets: 87,
    mitigated: false,
  },
  {
    id: "atk-003",
    timestamp: isoSec(142),
    type: "DNS Tunneling",
    sourceIp: "10.12.1.12",
    targetIp: "8.8.8.8",
    severity: "warning",
    stage: "C2 Channel",
    bytes: 91200,
    packets: 1840,
    mitigated: false,
  },
  {
    id: "atk-004",
    timestamp: isoSec(480),
    type: "Brute Force",
    sourceIp: "198.51.100.247",
    targetIp: "10.12.1.10",
    severity: "error",
    stage: "Initial Access",
    bytes: 7840,
    packets: 312,
    mitigated: true,
  },
];

export const mockLogLines: string[] = [
  `[2026-09-11T14:32:53Z] ids[1] CRITICAL: confirmed intrusion 198.51.100.247 → 10.12.1.10`,
  `[2026-09-11T14:32:47Z] ml[predict] WARN: anomaly_score=84 confidence=0.73 model=LSTM-v4.2`,
  `[2026-09-11T14:32:41Z] ids[1234] ALERT: ET SQL Injection -- BLIND (3) src=198.51.100.247:44821`,
  `[2026-09-11T14:32:39Z] fw WARN: edge utilization 91% — approaching saturation threshold`,
  `[2026-09-11T14:32:35Z] rt01 INFO: ECMP path selected via sw-dmz for 198.51.100.0/24`,
  `[2026-09-11T14:32:19Z] auth WARN: brute-force from 198.51.100.247 — 312 attempts in 120s`,
  `[2026-09-11T14:32:11Z] ids ALERT: fragmented packet reassembly bypass sequence`,
  `[2026-09-11T14:31:58Z] fw BLOCK: rule 147 src=198.51.100.247 dst=10.12.1.10 proto=TCP dport=22`,
  `[2026-09-11T14:31:35Z] fw DENY lateral POST 10.12.1.10→10.12.2.21:8080 — policy violation`,
  `[2026-09-11T14:30:31Z] dns WARN: query_rate=18420/min (baseline 4400/min) src=10.12.1.12`,
  `[2026-09-11T14:29:30Z] pgsql WARN: superuser escalation admin@10.12.2.100 — off-hours`,
  `[2026-09-11T14:28:44Z] ml[stream] INFO: telemetry batch processed 1024 flows`,
  `[2026-09-11T14:27:43Z] fw ALERT: fragmented bypass src=198.51.100.247 ttl=1 frag_off=0`,
  `[2026-09-11T14:26:12Z] sys INFO: heartbeat OK — all services nominal`,
  `[2026-09-11T14:25:23Z] ids INFO: ruleset updated v2026.09.11-1 rules=47382`,
];
